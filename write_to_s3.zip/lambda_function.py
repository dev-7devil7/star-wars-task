import json
from read_and_dump_to_json import *

def lambda_handler(event, context):
    
    read_and_dump_to_json()
